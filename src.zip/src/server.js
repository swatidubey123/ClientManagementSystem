//dependencies
const express=require('express')
const bodyParser=require('body-parser')
const cors=require('cors')
const mysql=require('mysql')


//define the express operation
const app=express();
const port=3000;
const bcrypt = require('bcrypt');

//defining the cors -cross origin by reciving the data in json format
app.use(cors());
app.use(bodyParser.json())


//establish the connection with the dB
const db=mysql.createConnection({
host:'localhost',
user:'root',
password:'root',
database:'db2'    
});


//verifying whether db is connected or not
db.connect(err=>{
if(err){
    console.error('connection is not established with the dB',err);
}
else{
    console.log('Connected to db')
}

});

app.listen(port,()=>{console.log('server port estbalished on 3000')})

//to get all the clients
app.get('/getClients',(req,res)=>{
const sql='select * from Client';
db.query(sql,(err,result)=>{
    if(err){
    console.error('Error in fetching the client',err);
    res.status(500).json({error:'An error occured'});
}else{
    res.status(200).json(result);
}

});
});
//to get a Client on id
app.get('/getClient/:id',(req,res)=>{
    const id=req.params.id;
    const sql='select * from client where id=?';
    db.query(sql,[id],(err,result)=>{
        if(err){
        console.error('Error in fetching the client',err);
        res.status(500).json({error:'An error occured'});
    }else{
        res.status(200).json(result);
    }
   
    });
    });
//to insert client into db
app.post('/registerClient',async(req,res)=>{
    const {id,name,email,adress,password}=req.body;
    const sql='insert into client values(?,?,?,?,?)';
    // Generate a salt and hash the password
    const saltRounds = 10; // Number of salt rounds
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    db.query(sql,[id,name,email,adress,hashedPassword],(err,result)=>{
        if(err){
            console.error('Error in adding the client',err);
            res.status(500).json({error:'An error occured'});
        }else{
            res.status(200).json({message:'client added successfully'});
        }

    });
    });
//updation of client
app.put('/updateClient',(req,res)=>{
    const {id,name,email,adress,password}=req.body;
    const sql='update client set name=?,email=?,adress=?,password=? where id=?';
    db.query(sql,[name,email,adress,password,id],(err,result)=>{
        if(err){
            console.error('Error in updating the client',err);
            res.status(500).json({error:'An error occured'});
        }else{
            res.status(200).json({message:'client updated successfully'});
        }

    });
    });
//deletion of client /deleteClient
app.delete('/deleteClient/:id',(req,res)=>{
    const id=req.params.id;
    const sql='delete from client where id=?';
    db.query(sql,[id],(err,result)=>{
        if(err){
        console.error('Error in deleting the client',err);
        res.status(500).json({error:'An error occured'});
    }else{
        res.status(200).json({message:'client deleted successfully'});
    }
   
    });
    });

    ///////////////////////meeting functions///////////////
    /////////to insert meeting details  into db
app.post('/addMeeting',(req,res)=>{
    const {meetingid,meeting_topic,meeting_member,meetingdate,meetingtime,client_id}=req.body;
    const sql='insert into meeting values(?,?,?,?,?,?)';
    db.query(sql,[meetingid,meeting_topic,meeting_member,meetingdate,meetingtime,client_id],(err,result)=>{
        if(err){
            console.error('Error in adding the meeting',err);
            res.status(500).json({error:'An error occured in adding meeting'});
        }else{
            res.status(200).json({message:'meeting added successfully'});
        }

    });
    });
//to get all the Meetings
app.get('/getMeetings',(req,res)=>{
    const sql='select * from Meeting';
    db.query(sql,(err,result)=>{
        if(err){
        console.error('Error in fetching the client',err);
        res.status(500).json({error:'An error occured'});
    }else{
        res.status(200).json(result);
    }
    
    });
    });
//to get a meeting on meetingid
app.get('/getMeeting/:meetingid',(req,res)=>{
    const meetingid=req.params.meetingid;
    const sql='select * from Meeting where meetingid=?';
    db.query(sql,[meetingid],(err,result)=>{
        if(err){
        console.error('Error in fetching the meeting',err);
        res.status(500).json({error:'An error in fetching meeting by id occured'});
    }else{
        res.status(200).json(result);
    }
   
    });
    });
    //updation of meeting
   
    app.put('/updateMeeting',(req,res)=>{
    const {meetingid,meeting_topic,meeting_member,meetingdate,meetingtime,client_id}=req.body;
    const sql='update meeting set meeting_topic=?,meeting_member=?,meetingdate=?,meetingtime=?,client_id=? where meetingid=?';
    db.query(sql,[meeting_topic,meeting_member,meetingdate,meetingtime,client_id,meetingid],(err,result)=>{
        if(err){
            console.error('Error in updating the meeting',err);
            res.status(500).json({error:'An error occured'});
        }else{
            res.status(200).json({message:'meeting updated successfully'});
        }

    });
    });
    //deletion of meeting /deleteMeeting
app.delete('/deleteMeeting/:meetingid',(req,res)=>{
    const meetingid=req.params.meetingid;
    const sql='delete from meeting where meetingid=?';
    db.query(sql,[meetingid],(err,result)=>{
        if(err){
        console.error('Error in deleting the Meeting',err);
        res.status(500).json({error:'An error occured'});
    }else{
        res.status(200).json({message:'Meeting deleted successfully'});
    }
   
    });
    });
