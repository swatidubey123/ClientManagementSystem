import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-meeting',
  templateUrl: './edit-meeting.component.html',
  styleUrls: ['./edit-meeting.component.css']
})
export class EditMeetingComponent implements OnInit {
  meetingid:number=0;
  meeting_topic:string='';
  meeting_member:number=0;
  meetingdate:string='';
  meetingtime:string='';
  client_id:number=0;
  message:string='';

  constructor(private http:HttpClient,private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params=>{
      const idParam=params.get('meetingid');
      if(idParam!==null){
        this.meetingid=+idParam;
        this.fetchMeeting();
      }
      else{
        console.error("meetingid is missing  or null");
      }

    })
  }
  fetchMeeting(){
    this.http.get('http://localhost:3000/getMeeting/'+this.meetingid)
        .subscribe((response:any)=>
      {
        const meeting=response[0];
        this.meeting_topic=meeting.meeting_topic;
        this.meeting_member=meeting.meeting_member;
        this.meetingdate=meeting.meetingdate;
        this.meetingtime=meeting.meetingtime;
        this.client_id=meeting.client_id;
       
      },
      (error)=>{console.error('Error fetching the meeting',error);}
    );
  }
  updateMeeting(){
    const meeting={
      meetingid:this.meetingid,
      meeting_topic:this.meeting_topic,
      meeting_member:this.meeting_member,
      meetingdate:this.meetingdate,
      meetingtime:this.meetingtime,
      client_id:this.client_id

    };

    this.http.put('http://localhost:3000/updateMeeting',meeting)
    .subscribe((response:any)=>
    {this.message=response.message;this.router.navigate(['/viewMeeting'])},
    (error)=>{console.error('Error updating the meeting',error);}
  );

  }

  

}
