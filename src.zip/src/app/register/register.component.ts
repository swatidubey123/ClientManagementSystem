import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit  {
id:number=0;
name:string='';
email:string='';
password:string='';
adress:string='';

message:string='';
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
  }
  registerClient(){
    const client={
      id:this.id,
      name:this.name,
      email:this.email,
      password:this.password,
      adress:this.adress
      

      }
      if(this.name===null){
        this.message="name can not be empty" ;
        console.error('Error adding the client');
        
    }
    ;
    this.http.post('http://localhost:3000/registerClient',client)
    .subscribe((response:any)=>
    {this.message=response.message},
    (error)=>{console.error('Error adding the client',error);}
  );
}


}
