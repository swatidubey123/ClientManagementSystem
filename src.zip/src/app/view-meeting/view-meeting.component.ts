import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-view-meeting',
  templateUrl: './view-meeting.component.html',
  styleUrls: ['./view-meeting.component.css']
})
export class ViewMeetingComponent implements OnInit{
  meetings:any[]=[];
message:string='';
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.fetchMeetings();
      }
      fetchMeetings(){
        this.http.get('http://localhost:3000/getMeetings')
          .subscribe((response:any)=>
        {this.meetings=response},
        (error)=>{console.error('Error fetching the Meetings',error);}
      );
      }

      deleteMeeting(meetingid:number){
        if(confirm('Are you sure you want to delete this meeting?')){
          this.http.delete('http://localhost:3000/deleteMeeting/'+meetingid)
          .subscribe((response:any)=>
        {this.message=response.message;
         
          this.fetchMeetings();},
       
        (error)=>{console.error('Error deleting the meeting',error);}
      );
    }
    }
}
