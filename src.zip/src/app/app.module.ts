import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { ViewClientComponent } from './view-client/view-client.component';
import { EditClientComponent } from './edit-client/edit-client.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CreateMeetingComponent } from './create-meeting/create-meeting.component';
import { ViewMeetingComponent } from './view-meeting/view-meeting.component';
import { EditMeetingComponent } from './edit-meeting/edit-meeting.component';

const routes:Routes=[
  {path:'',redirectTo:'/view',pathMatch:'full'},
  {path:'view',component:ViewClientComponent},
  {path:'',redirectTo:'/viewMeeting',pathMatch:'full'},
  {path:'viewMeeting',component:ViewMeetingComponent},
  {path:'clientMeeting',component:CreateMeetingComponent},
  //{path:'',redirectTo:'/view',pathMatch:'full'},
  {path:'register',component:RegisterComponent},
  {path:'',redirectTo:'/view',pathMatch:'full'},
  {path:'edit/:id',component:EditClientComponent},
  {path:'editMeeting/:meetingid',component:EditMeetingComponent}
  ]
  
@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    ViewClientComponent,
    EditClientComponent,
    CreateMeetingComponent,
    ViewMeetingComponent,
    EditMeetingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
