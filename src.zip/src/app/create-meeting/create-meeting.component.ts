import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-create-meeting',
  templateUrl: './create-meeting.component.html',
  styleUrls: ['./create-meeting.component.css']
})
export class CreateMeetingComponent implements OnInit{
  meetingid:number=0;
  meeting_topic:string='';
  meeting_member:number=0;
  meetingdate:string='';
  meetingtime:string='';
  client_id:number=0;
  message:string='';
    constructor(private http:HttpClient) { }
  
    ngOnInit(): void {
    }
    ScheduleMeeting(){
      const meeting={
        meetingid:this.meetingid,
        meeting_topic:this.meeting_topic,
        meeting_member:this.meeting_member,
        meetingdate:this.meetingdate,
        meetingtime:this.meetingtime,
        client_id:this.client_id
      };
  
      this.http.post('http://localhost:3000/addMeeting',meeting)
      .subscribe((response:any)=>
      {this.message=response.message},
      (error)=>{console.error('Error adding the Meeting schedule',error);}
    );


}
}
